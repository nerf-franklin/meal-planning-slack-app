from .ignoring_self_events import IgnoringSelfEvents

__all__ = [
    "IgnoringSelfEvents",
]
