import os
import requests
import json
import re
import logging
from slack_bolt import App
from slack_bolt.adapter.aws_lambda import SlackRequestHandler

# Initializes your app with your bot token and signing secret
app = App(
    token=os.environ.get("SLACK_BOT_TOKEN"),
    signing_secret=os.environ.get("SLACK_SIGNING_SECRET")
)

SPOONACULAR_BASE_URL = "https://api.spoonacular.com"
SPOONACULAR_API_KEY = "f4a8408868434667920f5402cb532130"
SPOONACULAR_HEADERS = {
    "Content-Type": 'application/json'
}

GENERATE_MEAL_PLAN_OPTIONS = {
    "timeFrame": "Day",
    "targetCalories": 1000,
    "diet": ""
}

RANDOM_RECIPE = {}

USER_INFO = {
    "username": "nick-f",
    "hash": "7d862e0ef625d762cd8c22a48b4513582ef01e15"
}

SAY_INVALID_CMD = "Sorry, I didn't recognize that command.  Please use `/nickbot guide` to see available commands."
SAY_SHOP_LIST_EMPTY = "Uh oh!  Your shopping list is currently *empty*.  Better start adding items..."

SPOON_BOT_CONVO_CONTEXT_ID = "112233445566778899"


# # # # # # # # # # # # # # # # # #
# #    DISPLAY / FORMATTING     # #
# # # # # # # # # # # # # # # # # #

block_divider = {
    "type": "divider"
}


# Create block to display nutrient info
def create_nutrient_display_block(nutrients: dict) -> dict:
    block_json = {
        "blocks": [
            block_divider,
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*Nutrients:*\nCalories: {nutrients.get('calories')}, Protein: {nutrients.get('protein')},"
                            f" Fat: {nutrients.get('fat')}, Carbs: {nutrients.get('carbohydrates')}"
                }
            }
        ]
    }

    return block_json


# Create block to display aisle info
def create_sorted_aisles_display_block(aisles: dict) -> dict:

    total_items = 0
    for aisle in aisles:
        total_items += len(aisle.get("items"))

    block_json = {"blocks": []}

    block_json.get("blocks").append(block_divider)
    block_json.get("blocks").append(
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": f"Sorted Shopping List ({total_items} items)"
            }
        }
    )
    for aisle in aisles:
        items_list = []
        for item in aisle.get("items"):
            items_list.append(f"{item.get('name')} ({item.get('measures').get('original').get('amount')}"
                              f" {item.get('measures').get('original').get('unit')})")
        items_joined = ", ".join(items_list)
        block_json.get("blocks").append(
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*{aisle.get('aisle')}*\n{items_joined}"
                }
            }
        )

    return block_json


# Create blocks to display daily meal plan with nutrient info
def display_daily_meal_plan_and_nutrients(daily_plan_info: dict) -> dict:

    block_json = {"blocks": []}

    block_json.get("blocks").append(block_divider)
    block_json.get("blocks").append(
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": "Single day meal plan"
            }
        }
    )

    nutrients = daily_plan_info.get("nutrients")

    for meal in daily_plan_info.get("meals"):
        block_json.get("blocks").append(
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*{meal.get('title')}*\nReady In: {meal.get('readyInMinutes')} minutes | Servings:"
                            f" {meal.get('servings')}\nSource: {meal.get('sourceUrl')}"
                }
            }
        )
    block_json.get("blocks").append(block_divider)
    block_json.get("blocks").append(
        {
            "type": "section",
            "text": {
                "type": "mrkdwn",
                "text": f"*Nutrients:*\nCalories: {nutrients.get('calories')}, Protein: {nutrients.get('protein')},"
                        f" Fat: {nutrients.get('fat')}, Carbs: {nutrients.get('carbohydrates')}\n"
            }
        }
    )
    block_json.get("blocks").append(block_divider)
    return block_json


# Create blocks to display detailed nutrient info for an ingredient -- NOT NEEDED ANY MORE?
def display_nutrition_details_for_ingredient(ingredient: dict) -> dict:
    block_json = {"blocks": []}
    name = ingredient.get("name")
    if ingredient.get("nutrition"):
        nutrition = ingredient.get("nutrition")
        nutrients = nutrition.get("nutrients")
        # properties = nutrition.get("properties")
        # flavonoids = nutrition.get("flavonoids")

        block_json.get("blocks").append(block_divider)
        block_json.get("blocks").append(
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"Nutrition Info - {name.capitalize()}"
                }
            }
        )

        for nutrient in nutrients:
            block_json.get("blocks").append(
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"{nutrient.get('name')} - {nutrient.get('amount')} {nutrient.get('unit')} |"
                                f" {nutrient.get('percentOfDailyNeeds')}% DV"
                    }
                }
            )

        return block_json


# Append detailed nutrient info to existing blocks list (for nutrient modal update)
def append_nutrient_info_to_block_list(blocks: list, ingredient: dict) -> list:
    block_list = blocks
    name = ingredient.get("name")
    if ingredient.get("nutrition"):
        nutrition = ingredient.get("nutrition")
        nutrients = nutrition.get("nutrients")
        # properties = nutrition.get("properties")
        # flavonoids = nutrition.get("flavonoids")

        block_list.append(block_divider)
        block_list.append(
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"Nutrition Info - {name.capitalize()}"
                }
            }
        )

        for nutrient in nutrients:
            block_list.append(
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"{nutrient.get('name')} - {nutrient.get('amount')} {nutrient.get('unit')} |"
                                f" {nutrient.get('percentOfDailyNeeds')}% DV"
                    }
                }
            )

        return block_list


# Combine duplicates items in list and update amounts
def combine_duplicate_items(items: list):
    new_list = []
    # TO DO
    return


# # # # # # # # # # # # # # # # # #
# #    SPOONACULAR REQUESTS     # #
# # # # # # # # # # # # # # # # # #


# Get user info
def load_user_info(username: str):
    global USER_INFO

    if USER_INFO["hash"] in ["hash"]:

        url_path = "/users/connect"
        url = f"{SPOONACULAR_BASE_URL}{url_path}"
        params = {
            'apiKey': SPOONACULAR_API_KEY,
        }
        payload = {
            "username": username
        }

        response = requests.post(url=url, json=payload, headers=SPOONACULAR_HEADERS, params=params)
        response_json = json.loads(response.content)

        # Logging debug
        print(f"Response from POST user connect: {response_json}")

        USER_INFO['username'] = response_json.get("username")
        USER_INFO['hash'] = response_json.get("hash")

    else:
        print("User info has already been loaded once...")

    return


# List all items in shopping list
def list_items_in_shopping_list() -> dict:
    global USER_INFO
    load_user_info("nick_test")
    username = USER_INFO["username"]
    user_hash = USER_INFO["hash"]
    url_path = f"/mealplanner/{username}/shopping-list"
    url = f"{SPOONACULAR_BASE_URL}{url_path}"
    params = {
        'apiKey': SPOONACULAR_API_KEY,
        'hash': user_hash
    }

    response = requests.get(url=url, headers=SPOONACULAR_HEADERS, params=params)

    # Logging debug
    print(f"Response from GET items in shopping list: {json.loads(response.content)}")

    return json.loads(response.content)


# Add item to shopping list
def add_item_to_shopping_list(item: str, parse: bool) -> dict:
    global USER_INFO
    load_user_info("nick_test")
    username = USER_INFO["username"]
    user_hash = USER_INFO["hash"]
    url_path = f"/mealplanner/{username}/shopping-list/items"
    url = f"{SPOONACULAR_BASE_URL}{url_path}"
    params = {
        'apiKey': SPOONACULAR_API_KEY,
        'hash': user_hash
    }
    payload = {
        "item": item,
        "parse": parse  # Will attempt to parse and analyze item or not
    }

    response = requests.post(url=url, json=payload, headers=SPOONACULAR_HEADERS, params=params)
    response_json = json.loads(response.content)

    # Logging debug
    print(f"Response from POST add to shopping list: {response_json}")
    return response_json


# Delete item from shopping list by name
def delete_item_from_shopping_list(item_name: str) -> dict:
    item_id = get_list_item_id_by_name(item_name)

    if item_id != "":
        global USER_INFO
        load_user_info("nick_test")
        username = USER_INFO["username"]
        user_hash = USER_INFO["hash"]
        url_path = f"/mealplanner/{username}/shopping-list/items/{item_id}"
        url = f"{SPOONACULAR_BASE_URL}{url_path}"
        params = {
            'apiKey': SPOONACULAR_API_KEY,
            'hash': user_hash
        }

        response = requests.delete(url=url, headers=SPOONACULAR_HEADERS, params=params)
        response_json = json.loads(response.content)

        # Logging debug
        print(f"Response from DEL remove item from shopping list: {response_json}")
        return response_json
    else:
        return {
            "not_found": item_name
        }


# Empty shopping list
def empty_shopping_list() -> dict:
    total_deleted = 0
    list_response = list_items_in_shopping_list()
    if len(list_response) > 0:
        for aisle in list_response.get("aisles"):
            for item in aisle.get("items"):
                delete_item_from_shopping_list(item.get("name"))
                total_deleted += total_deleted
    return {
        "total_deleted": total_deleted
    }


# Get shopping list item id from name
def get_list_item_id_by_name(item_name: str) -> dict:
    item_id = ""
    current_list = list_items_in_shopping_list()
    for aisle in current_list.get("aisles"):
        for item in aisle.get("items"):
            if item.get("name").lower() == item_name.lower():
                item_id = item.get("id")
                break
    return item_id


# Search all recipes using natural language search query
def search_all_recipes(query: str) -> dict:
    url_path = "/recipes/complexSearch"
    url = f"{SPOONACULAR_BASE_URL}{url_path}"
    params = {
        'apiKey': SPOONACULAR_API_KEY,
        'query': query
    }

    response = requests.get(url=url, headers=SPOONACULAR_HEADERS, params=params)

    # Logging debug
    print(f"Response from GET recipes search: {json.loads(response.content)}")

    return json.loads(response.content)


# Search all recipes by ingredients list
def search_all_recipes_by_ingredients(ingredients: list) -> dict:
    # Change list to comma separated string for params
    comma_sep_ingredients = ",".join(ingredients)

    url_path = "/recipes/findByIngredients"
    url = f"{SPOONACULAR_BASE_URL}{url_path}"
    params = {
        'apiKey': SPOONACULAR_API_KEY,
        'ingredients': comma_sep_ingredients,
        'number': 5,
        'ignorePantry': True
    }

    response = requests.get(url=url, headers=SPOONACULAR_HEADERS, params=params)

    # Logging debug
    print(f"Response from GET recipes by ingredients search: {json.loads(response.content)}")

    return json.loads(response.content)


# Get random recipe
def get_random_recipe() -> dict:
    url_path = "/recipes/random"
    url = f"{SPOONACULAR_BASE_URL}{url_path}"
    params = {
        'apiKey': SPOONACULAR_API_KEY
    }

    response = requests.get(url=url, headers=SPOONACULAR_HEADERS, params=params)

    # Logging debug
    print(f"Response from GET random recipe: {json.loads(response.content)}")

    return json.loads(response.content)


# Generate meal plan
def generate_meal_plan(time_frame: str, target_calories: int, diet: str, exclude: str) -> dict:
    url_path = "/mealplanner/generate"
    url = f"{SPOONACULAR_BASE_URL}{url_path}"
    params = {
        'apiKey': SPOONACULAR_API_KEY,
        'timeFrame': time_frame,
        'targetCalories': target_calories,
        'diet': diet,
        'exclude': exclude
    }

    response = requests.get(url=url, headers=SPOONACULAR_HEADERS, params=params)

    # Logging debug
    print(f"Response from Generate meal plan: {json.loads(response.content)}")

    return json.loads(response.content)


# Add an item to the user's meal plan
def add_item_to_meal_plan(item_type: str, date: int, slot: int, position: int) -> dict:
    global USER_INFO
    load_user_info("nick_test")
    username = USER_INFO["username"]
    user_hash = USER_INFO["hash"]
    url_path = f"/mealplanner/{username}/items"
    url = f"{SPOONACULAR_BASE_URL}{url_path}"
    params = {
        'apiKey': SPOONACULAR_API_KEY,
        'hash': user_hash
    }
    payload = {
        "type": item_type,
        "date": date,
        "slot": slot,
        "position": position,
        "value": {
            "id": "id",
            "servings": "servings",
            "title": "title",
            "imageType": "jpg"
        }
    }

    response = requests.post(url=url, json=payload, headers=SPOONACULAR_HEADERS, params=params)

    # Logging debug
    print(f"Response from POST item to meal plan: {json.loads(response.content)}")

    return json.loads(response.content)


# Search all ingredients
def search_all_ingredients(query: str) -> dict:
    url_path = "/food/ingredients/search"
    url = f"{SPOONACULAR_BASE_URL}{url_path}"
    params = {
        'apiKey': SPOONACULAR_API_KEY,
        'query': query,
        'addChildren': True,
        'number': 20
    }

    response = requests.get(url=url, headers=SPOONACULAR_HEADERS, params=params)

    # Logging debug
    print(f"Response from Generate meal plan: {json.loads(response.content)}")

    return json.loads(response.content)


# Talk to Spoonacular's chatbot
def talk_to_spoon_bot(text: str) -> dict:
    url_path = "/food/converse"
    url = f"{SPOONACULAR_BASE_URL}{url_path}"
    params = {
        'apiKey': SPOONACULAR_API_KEY,
        "text": text,
        "contextId": SPOON_BOT_CONVO_CONTEXT_ID
    }

    response = requests.get(url=url, headers=SPOONACULAR_HEADERS, params=params)

    # Logging debug
    print(f"Response from Talk to Spoonacular bot: {json.loads(response.content)}")

    return json.loads(response.content)


# GET ingredient details by id
def get_ingredient_info_by_id(ingred_id: str) -> dict:
    url_path = f"/food/ingredients/{ingred_id}/information"
    url = f"{SPOONACULAR_BASE_URL}{url_path}"
    params = {
        'apiKey': SPOONACULAR_API_KEY,
        'amount': 1
    }

    response = requests.get(url=url, headers=SPOONACULAR_HEADERS, params=params)

    # Logging debug
    print(f"Response from GET ingredient details: {json.loads(response.content)}")

    return json.loads(response.content)


# GET recipe details by id
def get_recipe_by_id(recipe_id: str) -> dict:
    url_path = f"/recipes/{recipe_id}/information"
    url = f"{SPOONACULAR_BASE_URL}{url_path}"
    params = {
        'apiKey': SPOONACULAR_API_KEY,
        "id": recipe_id,
        "includeNutrition": True
    }

    response = requests.get(url=url, headers=SPOONACULAR_HEADERS, params=params)

    # Logging debug
    print(f"Response from GET recipe details by id: {json.loads(response.content)}")

    return json.loads(response.content)


# Add all ingredients from a recipe to the shopping list
def add_recipe_ingredients_to_shop_list(recipe_id: str) -> dict:
    recipe_response = get_recipe_by_id(recipe_id)
    items_added = []
    total_added = 0
    extended_ingredients = recipe_response.get("extendedIngredients")
    for ingred in extended_ingredients:
        name = ingred.get("nameClean") if ingred.get("nameClean") else ingred.get("name")
        item_to_add = f"{ingred.get('amount')} {ingred.get('unit')} {name}"
        add_item_to_shopping_list(item_to_add, True)
        items_added.append(item_to_add)
        total_added = total_added + 1

    return {
        "recipe_id": recipe_id,
        "items_added": items_added,
        "total_added": total_added
    }


# # # # # # # # # # # # # # # # # #
# #    LISTENING TO EVENTS      # #
# # # # # # # # # # # # # # # # # #


@app.event("app_home_opened")
def update_home_tab(client, event, logger):
    try:
        # views.publish is the method that your app uses to push a view to the Home tab
        client.views_publish(
            # the user that opened your app's app home
            user_id=event["user"],
            # the view object that appears in the app home
            view={
                "type": "home",
                "callback_id": "home_view",

                # body of the view
                "blocks": [
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": "*Welcome to Nick's Nutrition Bot Home* :tada:"
                        }
                    },
                    {
                        "type": "divider"
                    },
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": "More coming soon... Please use `/nickbot guide` to see what I can do!"
                        }
                    }
                ]
            }
        )

    except Exception as e:
        logger.error(f"Error publishing home tab: {e}")


@app.event("message")
def handle_message_events(say, body, logger):

    msg_incoming = body.get("event").get("blocks")[0].get("elements")[0].get("elements")[0].get("text").lower()
    print(f"Received msg: {msg_incoming}")
    if msg_incoming is not None and ("command" in msg_incoming or "help" in msg_incoming or "guide" in msg_incoming):
        say("Yeah...better try `/nickbot guide` to get more info...")
    elif msg_incoming is not None and "hello" in msg_incoming:
        say("Hey there! How's your day so far?  Mine's ok but I'm stuck indoors.")
    elif msg_incoming is not None and "joke" in msg_incoming:
        say("Joke? Look in the mirror.")
    elif msg_incoming is not None and "recipe" in msg_incoming:
        say("Looking for a recipe? Check out the recipe commands by typing `/nickbot guide`")
    elif msg_incoming is not None and ("shopping" in msg_incoming or "grocery" in msg_incoming or "groceries" in msg_incoming):
        say("Need to do some shopping? Check out the shoplist commands by typing `/nickbot guide`")
    else:
        say("Are you talking to me?  I was asleep.")


# # # # # # # # # # # # # # # # # #
# #    LISTENING TO COMMANDS    # #
# # # # # # # # # # # # # # # # # #

@app.command("/nickbot")
def show_guide(ack, say, command):
    # Acknowledge command request
    ack()

    say({
        "text": "NickBot Guide",
        "blocks": [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "*These are the available NickBot commands:*"
                }
            },
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "`/nickbot` or `/nickbot guide` Show the guide"
                }
            },
            block_divider,
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "`/recipe random` Get a random recipe\n`/recipe ingredients` Search recipes using the "
                            "ingredients you have\n`/recipe search` Search for recipes with any phrase\n`/recipe "
                            "crazysearch` Search recipes with advanced options (TO DO)"
                }
            },
            block_divider,
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "`/shoplist list` List all items in shopping list\n`/shoplist sort`"
                            " Attempt to analyze items and sort by aisle\n`/shoplist add` Add an item to your "
                            "shopping list\n`/shoplist delete` Remove a specific item from your shopping list\n"
                            "`/shoplist empty` Remove all items from your shopping list"
                }
            },
            block_divider,
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "`/mealplan generate` Generate a new meal plan"
                }
            },
            block_divider,
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": "`/nutrients` Search nutrient info for an ingredient"
                }
            }
        ]
    })


@app.command("/recipe")
def recipe_process(ack, say, command):
    # Acknowledge command request
    ack()

    recipe_cmd = command['text'].split(' ', 1)[0]
    print(f"\nReceived cmd /recipe {command['text']}.\n")

    # RANDOM
    if recipe_cmd.startswith("random"):
        random_response = get_random_recipe()
        recipe = random_response.get("recipes")[0]
        title = recipe.get("title")
        img_url = recipe.get("image", "No image found")

        if recipe.get("summary"):
            summary = recipe.get("summary").replace('<b>', '*').replace('</b>', '*')
            summary = re.sub(r'<.*?', '', summary)
            summary = f"{summary[:350]}..."
        else:
            summary = "No summary found..."

        source_url = recipe.get("sourceUrl")
        extended_ingred_list = []
        for ingred in recipe.get("extendedIngredients"):
            extended_ingred_list.append(ingred.get("original"))
        ingreds_joined = ", ".join(extended_ingred_list)
        ready_in_mins = recipe.get("readyInMinutes")
        recipe_id = recipe.get("id")

        say({
            "text": "Random recipe",
            "blocks": [
                block_divider,
                {
                    "type": "header",
                    "text": {
                        "type": "plain_text",
                        "text": f"{title}"
                    }
                },
                block_divider,
                {
                    "type": "image",
                    "title": {
                        "type": "plain_text",
                        "text": f"Image of {title}"
                    },
                    "image_url": img_url,
                    "alt_text": f"Image of {title}"
                },
                block_divider,
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"    {summary}"
                    }
                },
                block_divider,
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"*Ingredients*: \n{ingreds_joined}\n\n*Ready in*: {ready_in_mins} mins"
                    }
                },
                {
                    "type": "actions",
                    "block_id": "random_recipe_action",
                    "elements": [
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "text": "Add all to shopping list"
                            },
                            "value": str(recipe_id),
                            "action_id": "random_recipe_add_all_to_shop_list"
                        },
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "text": "Show instructions"
                            },
                            "value": str(recipe_id),
                            "action_id": "recipe_show_instructions"
                        },
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "text": "View Source"
                            },
                            "value": str(recipe_id),
                            "action_id": "random_recipe_view_source",
                            "url": source_url
                        }
                    ]
                },
                block_divider
            ]
        })

    # INGREDIENTS
    elif recipe_cmd.startswith("ingredients"):
        say({
            "text": "Ingredient Multi Select",
            "blocks": [
                block_divider,
                {
                    "type": "section",
                    "block_id": "ingred_multi_select",
                    "text": {
                        "type": "mrkdwn",
                        "text": "Select your ingredients:"
                    },
                    "accessory": {
                        "action_id": "ingred_multi_select",
                        "type": "multi_external_select",
                        "placeholder": {
                            "type": "plain_text",
                            "text": "What's in your fridge?"
                        },
                        "min_query_length": 1
                    }
                }
            ]
        })

    # SEARCH
    elif recipe_cmd.startswith("search"):
        search_response = search_all_recipes(command['text'][6:])
        total_results = search_response.get("totalResults")

        if total_results < 1:
            say("Sorry, no results were found!  You're too creative for me!")
        else:
            first_result = search_response.get("results")[0]
            recipe_id = first_result.get("id")
            recipe = get_recipe_by_id(recipe_id)
            title = recipe.get("title")
            img_url = recipe.get("image", "No image found")

            if recipe.get("summary"):
                summary = recipe.get("summary").replace('<b>', '*').replace('</b>', '*')
                summary = re.sub(r'<.*?', '', summary)
                summary = f"{summary[:350]}..."
            else:
                summary = "No summary found..."

            source_url = recipe.get("sourceUrl")
            extended_ingred_list = []
            for ingred in recipe.get("extendedIngredients"):
                extended_ingred_list.append(ingred.get("original"))
            ingreds_joined = ", ".join(extended_ingred_list)
            ready_in_mins = recipe.get("readyInMinutes")
            recipe_id = recipe.get("id")

            say({
                "text": "Top Recipe Found",
                "blocks": [
                    block_divider,
                    {
                        "type": "header",
                        "text": {
                            "type": "plain_text",
                            "text": f"{title}"
                        }
                    },
                    block_divider,
                    {
                        "type": "image",
                        "title": {
                            "type": "plain_text",
                            "text": f"Image of {title}"
                        },
                        "image_url": img_url,
                        "alt_text": f"Image of {title}"
                    },
                    block_divider,
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": f"*Summary*: {summary}"
                        }
                    },
                    block_divider,
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": f"*Ingredients*: {ingreds_joined}\n\n*Ready in*: {ready_in_mins} mins"
                        }
                    },
                    {
                        "type": "actions",
                        "block_id": "random_recipe_action",
                        "elements": [
                            {
                                "type": "button",
                                "text": {
                                    "type": "plain_text",
                                    "text": "Add all to shopping list"
                                },
                                "value": str(recipe_id),
                                "action_id": "random_recipe_add_all_to_shop_list"
                            },
                            {
                                "type": "button",
                                "text": {
                                    "type": "plain_text",
                                    "text": "Show instructions"
                                },
                                "value": str(recipe_id),
                                "action_id": "recipe_show_instructions"
                            },
                            {
                                "type": "button",
                                "text": {
                                    "type": "plain_text",
                                    "text": "View Source"
                                },
                                "value": str(recipe_id),
                                "action_id": "random_recipe_view_source",
                                "url": source_url
                            }
                        ]
                    },
                    block_divider
                ]
            })

    elif recipe_cmd.startswith("crazysearch"):
        say("Crazy search is not yet available...thanks for your patience!")
    else:
        say(SAY_INVALID_CMD)


@app.command("/shoplist")
def shoplist_process(ack, say, command):
    # Acknowledge command request
    ack()

    shoplist_cmd = command['text'].split(' ', 1)[0]
    print(f"\nReceived cmd /shoplist {command['text']}.\n")

    if shoplist_cmd.startswith("list"):
        list_response = list_items_in_shopping_list()
        items = []
        if len(list_response.get("aisles")) > 0:
            for aisle in list_response.get("aisles"):
                for item in aisle.get("items"):
                    items.append(f"{item.get('name')} ({item.get('measures').get('original').get('amount')}"
                                 f" {item.get('measures').get('original').get('unit')})")

            # items = combine_duplicate_items(items)

            spaced_list = '\n'.join(items)

            say({
                "blocks": [
                    block_divider,
                    {
                        "type": "header",
                        "text": {
                            "type": "plain_text",
                            "text": f"Your Shopping List ({len(items)} items)"
                        }
                    },
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": f"{spaced_list}"
                        },
                        "accessory": {
                            "type": "image",
                            "image_url": "https://cdn.discordapp.com/attachments/933565701162168371/1025651881172799579/template_shopping_cart_8e589110-9d3b-41c3-93ca-1258c2a94b1f.png",
                            "alt_text": f"Shopping Cart Icon"
                        }
                    }
                ]
            })
        else:
            say(SAY_SHOP_LIST_EMPTY)

    elif shoplist_cmd.startswith("sort"):
        list_response = list_items_in_shopping_list()
        if len(list_response.get("aisles")) > 0:
            say(create_sorted_aisles_display_block(list_response.get("aisles")))
        else:
            say(SAY_SHOP_LIST_EMPTY)

    elif shoplist_cmd.startswith("add"):
        item = command['text'][4:]
        add_response = add_item_to_shopping_list(item, True)
        if len(add_response) > 0:
            say({
                "blocks": [
                    block_divider,
                    {
                        "type": "section",
                        "text": {
                            "type": "mrkdwn",
                            "text": f"Added *{item}* to shopping list"
                        }
                    }
                ]
            })
        else:
            say(f"Oh no!  There was an issue adding {item} to your shopping list.")

    elif shoplist_cmd.startswith("delete"):
        if command['text'] == "delete":
            say("You didn't specify an item to delete... try `/shoplist delete ITEM_HERE`")
        else:
            item_del = command['text'][7:]
            del_response = delete_item_from_shopping_list(item_del)
            if del_response.get("not_found"):
                say(f"Uh oh!  Could not find or delete {item_del} from your shopping list")
            else:
                say(f"Deleted {item_del} from your shopping list")

    elif shoplist_cmd.startswith("empty"):
        say("Emptying shopping list...")
        empty_shopping_list()
        say("Shopping list is now empty")

    else:
        say(SAY_INVALID_CMD)


@app.command("/mealplan")
def mealplan_process(ack, say, command):
    # Acknowledge command request
    ack()

    mealplan_cmd = command['text'].split(' ', 1)[0]
    print(f"\nReceived cmd /mealplan {command['text']}.\n")

    if mealplan_cmd.startswith("generate"):
        say({
            "blocks": [
                block_divider,
                {
                    "type": "header",
                    "text": {
                        "type": "plain_text",
                        "text": "Let's generate a meal plan!"
                    }
                },
                {  # Day or Week picker
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": "Meal plan for one day or an entire week?"
                    },
                    "accessory": {
                        "type": "static_select",
                        "placeholder": {
                            "type": "plain_text",
                            "text": "Day or Week",
                            "emoji": True
                        },
                        "options": [
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "Day",
                                    "emoji": True
                                },
                                "value": "Day"
                            }
                            #{
                                #"text": {
                                    #"type": "plain_text",
                                    #"text": "Week",
                                    #"emoji": True
                                #},
                                #"value": "Week"
                            #}
                        ],
                        "action_id": "static_select_day_week-action"
                    }
                },
                {  # Diet picker
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": "Does this plan need to adhere to a diet?"
                    },
                    "accessory": {
                        "type": "static_select",
                        "placeholder": {
                            "type": "plain_text",
                            "text": "Select an item",
                            "emoji": True
                        },
                        "options": [
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "None",
                                    "emoji": True
                                },
                                "value": "None"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "Gluten Free",
                                    "emoji": True
                                },
                                "value": "Gluten Free"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "Ketogenic",
                                    "emoji": True
                                },
                                "value": "Ketogenic"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "Vegetarian",
                                    "emoji": True
                                },
                                "value": "Vegetarian"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "Vegan",
                                    "emoji": True
                                },
                                "value": "Vegan"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "Lacto-Vegetarian",
                                    "emoji": True
                                },
                                "value": "Lacto-Vegetarian"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "Ovo-Vegetarian",
                                    "emoji": True
                                },
                                "value": "Ovo-Vegetarian"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "Paleo",
                                    "emoji": True
                                },
                                "value": "Paleo"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "Pescetarian",
                                    "emoji": True
                                },
                                "value": "Pescetarian"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "Primal",
                                    "emoji": True
                                },
                                "value": "Primal"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "Low FODMAP",
                                    "emoji": True
                                },
                                "value": "Low FODMAP"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "Whole30",
                                    "emoji": True
                                },
                                "value": "Whole30"
                            }

                        ],
                        "action_id": "static_select_diet-action"
                    }
                },
                {  # Calorie Picker
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": "What is the caloric target for one day?"
                    },
                    "accessory": {
                        "type": "static_select",
                        "placeholder": {
                            "type": "plain_text",
                            "text": "Select an option",
                            "emoji": True
                        },
                        "options": [
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "0",
                                    "emoji": True
                                },
                                "value": "0"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "250",
                                    "emoji": True
                                },
                                "value": "250"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "500",
                                    "emoji": True
                                },
                                "value": "500"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "750",
                                    "emoji": True
                                },
                                "value": "750"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "1000",
                                    "emoji": True
                                },
                                "value": "1000"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "1250",
                                    "emoji": True
                                },
                                "value": "1250"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "1500",
                                    "emoji": True
                                },
                                "value": "1500"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "1750",
                                    "emoji": True
                                },
                                "value": "1750"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "2000",
                                    "emoji": True
                                },
                                "value": "2000"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "2250",
                                    "emoji": True
                                },
                                "value": "2250"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "2500",
                                    "emoji": True
                                },
                                "value": "2500"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "2750",
                                    "emoji": True
                                },
                                "value": "2750"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "3000",
                                    "emoji": True
                                },
                                "value": "3000"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "3250",
                                    "emoji": True
                                },
                                "value": "3250"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "3500",
                                    "emoji": True
                                },
                                "value": "3500"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "4000",
                                    "emoji": True
                                },
                                "value": "4000"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "4500",
                                    "emoji": True
                                },
                                "value": "4500"
                            },
                            {
                                "text": {
                                    "type": "plain_text",
                                    "text": "5000",
                                    "emoji": True
                                },
                                "value": "5000"
                            }
                        ],
                        "action_id": "static_select_calorie-action"
                    }
                },
                {
                    "type": "actions",
                    "elements": [
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "text": "Generate Meal Plan",
                                "emoji": True
                            },
                            "value": "click_me_generate_plan",
                            "action_id": "actionId-generate_plan",
                            "style": "primary"
                        }
                    ]
                }
            ]
        })
        # generate_response = generate_meal_plan(time_frame, target_calories, diet, exclude)
    else:
        say(SAY_INVALID_CMD)


@app.command("/nutrients")
def nutrients_process(ack, say, body, command, client):
    # Acknowledge command request
    ack()

    client.views_open(
        # Pass a valid trigger_id within 3 seconds of receiving it
        trigger_id=body["trigger_id"],
        # View payload
        view={
            "type": "modal",
            # View identifier
            "callback_id": "modal_nutrients",
            "title": {"type": "plain_text", "text": "Search Nutrient Info"},
            "blocks": [
                block_divider,
                {
                    "type": "section",
                    "block_id": "ingred_nutrient_select",
                    "text": {
                        "type": "mrkdwn",
                        "text": "Find an ingredient to get nutrient info:"
                    },
                    "accessory": {
                        "action_id": "ingred_nutrient_select",
                        "type": "external_select",
                        "placeholder": {
                            "type": "plain_text",
                            "text": "Search ingredients"
                        },
                        "min_query_length": 1
                    }
                }
            ]
        }
    )


# # # # # # # # # # # # # # # # # #
# #    LISTENING TO ACTIONS     # #
# # # # # # # # # # # # # # # # # #

@app.action("random_recipe_view_source")
def random_recipe_view_source(ack, body, logger):
    ack()
    logger.info(body)


@app.action("recipe_show_instructions")
def open_instructions_modal(ack, body, client, logger):
    ack()
    logger.info(body)
    print(body)
    recipe_id = body.get("actions")[0].get("value")
    recipe = get_recipe_by_id(recipe_id)
    # instructions = re.sub(r'<.*?>', '', recipe.get("instructions", ""))
    analyzed_instructions = recipe.get("analyzedInstructions", "")
    numbered_instructions = ''
    title = recipe.get("title")

    for instruction in analyzed_instructions:
        for step in instruction.get("steps"):
            numbered_instructions += f"*{step.get('number')})* {step.get('step')}\n"

    client.views_open(
        # Pass a valid trigger_id within 3 seconds of receiving it
        trigger_id=body["trigger_id"],
        # View payload
        view={
            "type": "modal",
            # View identifier
            "callback_id": "view_1",
            "title": {"type": "plain_text", "text": "Recipe Instructions"},
            "blocks": [
                {
                    "type": "header",
                    "text": {"type": "plain_text", "text": title}
                },
                {
                    "type": "section",
                    "text": {"type": "mrkdwn", "text": numbered_instructions}
                }
            ]
        }
    )


@app.action("ingred_nutrient_select")
def ingred_nutrient_select(ack, say, body, logger, client):
    ack()
    print(f"Ingredient nutrient select body: {body}")
    logger.info(body)

    ingred_id = body.get("actions")[0].get("selected_option").get("value")
    ingred_name = body.get("actions")[0].get("selected_option").get("text").get("text")
    print(f"\nSelected {ingred_name} with id {ingred_id}.")

    ingredient_response = get_ingredient_info_by_id(ingred_id)
    # say(display_nutrition_details_for_ingredient(ingredient_response))

    blocks = [
        block_divider,
        {
            "type": "section",
            "block_id": "ingred_nutrient_select",
            "text": {
                "type": "mrkdwn",
                "text": "Find an ingredient to get nutrient info:"
            },
            "accessory": {
                "action_id": "ingred_nutrient_select",
                "type": "external_select",
                "placeholder": {
                    "type": "plain_text",
                    "text": "Search ingredients"
                },
                "min_query_length": 1
            }
        }
    ]

    blocks = append_nutrient_info_to_block_list(blocks, ingredient_response)

    client.views_update(
        view_id=body["view"]["id"],
        hash=body["view"]["hash"],
        view={
            "type": "modal",
            # View identifier
            "callback_id": "view_show_nutrient_info",
            "title": {"type": "plain_text", "text": "Search Nutrition Info"},
            "blocks": blocks
        }
    )


@app.action("ingred_multi_select")
def ingredients_selected_action(ack, say, body, logger):
    ack()
    print(f"Multi select body: {body}")
    logger.info(body)
    search_list = []

    say("Searching for recipes with your ingredients...")

    for option in body.get("actions")[0].get("selected_options"):
        search_list.append(option.get("value"))

    search_response = search_all_recipes_by_ingredients(search_list)
    print(f"\n\nSearch recipes by ingredients response: {search_response}")

    if len(search_response) < 1:
        say("Oh no!  We couldn't find any recipes with that ingredient list!")
    else:
        blocks = {
            "text": "Ingredients Recipe Results",
            "blocks": []
        }
        blocks.get("blocks").append(block_divider)

        for recipe in search_response:
            title = recipe.get("title")
            recipe_id = recipe.get("id")
            img_url = recipe.get("image", "No image found")
            extended_used_ingred_list, extended_missing_ingred_list = [], []
            for ingred in recipe.get("usedIngredients"):
                extended_used_ingred_list.append(ingred.get("original"))
            for ingred in recipe.get("missedIngredients"):
                extended_missing_ingred_list.append(ingred.get("original"))
            used_ingreds_joined = ", ".join(extended_used_ingred_list) if len(
                extended_used_ingred_list) > 0 else "No used ingredients..."
            missing_ingreds_joined = ", ".join(extended_missing_ingred_list) if len(
                extended_missing_ingred_list) > 0 else "No missed ingredients..."
            blocks.get("blocks").append(
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"*{title}*\n*Used Ingredients*: {used_ingreds_joined}\n*Missing Ingredients*: {missing_ingreds_joined}"
                    },
                    "accessory": {
                        "type": "image",
                        "image_url": img_url,
                        "alt_text": f"Img of {title}"
                    }
                }
            )
            blocks.get("blocks").append(
                {
                    "type": "actions",
                    "block_id": f"ingred_results_{recipe_id}",
                    "elements": [
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "text": "View full recipe"
                            },
                            "value": str(recipe_id),
                            "action_id": "ingred_recipe_show_full_recipe"
                        },
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "text": "Add missing to shopping list"
                            },
                            "value": missing_ingreds_joined,
                            "action_id": "ingred_recipe_add_missing_to_shop_list"
                        }
                    ]
                }
            )
            blocks.get("blocks").append(block_divider)

        say(blocks)


@app.action("static_select_day_week-action")
def static_select_day_week(ack, body, logger):
    ack()
    logger.info(body)

    # Get timeFrame from body
    time_frame = body.get("actions")[0].get("selected_option").get("value")
    print(f"Meal plan day picker: {time_frame}")

    global GENERATE_MEAL_PLAN_OPTIONS
    GENERATE_MEAL_PLAN_OPTIONS['timeFrame'] = time_frame


@app.action("static_select_diet-action")
def static_select_diet(ack, body, logger):
    ack()
    logger.info(body)

    # Get diet from body
    diet = body.get("actions")[0].get("selected_option").get("value")
    print(f"Meal plan diet picker: {diet}")

    global GENERATE_MEAL_PLAN_OPTIONS
    GENERATE_MEAL_PLAN_OPTIONS['diet'] = diet if diet != "None" else ""


@app.action("static_select_calorie-action")
def static_select_calorie(ack, body, logger):
    ack()
    logger.info(body)

    # Get calories from body
    calories = body.get("actions")[0].get("selected_option").get("value")
    print(f"Meal plan calorie picker: {calories}")

    global GENERATE_MEAL_PLAN_OPTIONS
    GENERATE_MEAL_PLAN_OPTIONS['targetCalories'] = calories


@app.action("actionId-generate_plan")
def generate_meal_plan(ack, say, body, logger):
    ack()
    print(f"Generate meal plan button was pressed!")
    logger.info(body)

    global GENERATE_MEAL_PLAN_OPTIONS

    generate_meal_plan_response = generate_meal_plan(GENERATE_MEAL_PLAN_OPTIONS['timeFrame'],
                                                     GENERATE_MEAL_PLAN_OPTIONS['targetCalories'],
                                                     GENERATE_MEAL_PLAN_OPTIONS['diet'], "")

    if generate_meal_plan_response.get("week"):
        mon_plan = generate_meal_plan_response.get("week").get("monday")
        tues_plan = generate_meal_plan_response.get("week").get("tuesday")
        wed_plan = generate_meal_plan_response.get("week").get("wednesday")
        thurs_plan = generate_meal_plan_response.get("week").get("thursday")
        fri_plan = generate_meal_plan_response.get("week").get("friday")
        sat_plan = generate_meal_plan_response.get("week").get("saturday")
        sun_plan = generate_meal_plan_response.get("week").get("sunday")

        say({
            "blocks": [
                block_divider,
                {
                    "type": "header",
                    "text": {
                        "type": "plain_text",
                        "text": "Your 7 day meal plan"
                    }
                }
            ]
        })

    else:
        say(display_daily_meal_plan_and_nutrients(generate_meal_plan_response))


# Add all ingredients from random recipe to shopping list
@app.action("random_recipe_add_all_to_shop_list")
def random_recipe_add_all_to_shop_list(ack, say, body, logger):
    ack()
    print(body)
    logger.info(body)

    recipe_id = body.get("actions")[0].get("value")

    say("Yay!  Someone is hungry today.  Adding items now...")
    add_response = add_recipe_ingredients_to_shop_list(recipe_id)
    total_added = add_response.get("total_added")

    if add_response:
        say({
            "blocks": [
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"*Awesome!* {total_added} items were added to your shopping list"
                    }
                }
            ]
        })
    else:
        say("Uh oh!  Something went wrong...")


@app.action("ingred_recipe_show_full_recipe")
def show_full_recipe_from_results_list(ack, say, body, logger):
    ack()
    print(body)
    logger.info(body)

    recipe_id = body.get("actions")[0].get("value")
    recipe = get_recipe_by_id(recipe_id)

    # recipe = recipe_response.get("recipes")[0]
    title = recipe.get("title")
    img_url = recipe.get("image", "No image found")

    if recipe.get("summary"):
        summary = recipe.get("summary").replace('<b>', '*').replace('</b>', '*')
        summary = re.sub(r'<.*?', '', summary)
        summary = f"{summary[:350]}..."
    else:
        summary = "No summary found..."

    source_url = recipe.get("sourceUrl")
    extended_ingred_list = []
    for ingred in recipe.get("extendedIngredients"):
        extended_ingred_list.append(ingred.get("original"))
    ingreds_joined = ", ".join(extended_ingred_list)
    ready_in_mins = recipe.get("readyInMinutes")
    recipe_id = recipe.get("id")

    say(
        say({
            "text": "Random recipe",
            "blocks": [
                block_divider,
                {
                    "type": "header",
                    "text": {
                        "type": "plain_text",
                        "text": f"{title}"
                    }
                },
                block_divider,
                {
                    "type": "image",
                    "title": {
                        "type": "plain_text",
                        "text": f"Image of {title}"
                    },
                    "image_url": img_url,
                    "alt_text": f"Image of {title}"
                },
                block_divider,
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"    {summary}"
                    }
                },
                block_divider,
                {
                    "type": "section",
                    "text": {
                        "type": "mrkdwn",
                        "text": f"*Ingredients*: \n{ingreds_joined}\n\n*Ready in*: {ready_in_mins} mins"
                    }
                },
                {
                    "type": "actions",
                    "block_id": "ingred_recipe_action",
                    "elements": [
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "text": "Add all to shopping list"
                            },
                            "value": str(recipe_id),
                            "action_id": "random_recipe_add_all_to_shop_list"
                        },
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "text": "Show instructions"
                            },
                            "value": str(recipe_id),
                            "action_id": "recipe_show_instructions"
                        },
                        {
                            "type": "button",
                            "text": {
                                "type": "plain_text",
                                "text": "View Source"
                            },
                            "value": str(recipe_id),
                            "action_id": "random_recipe_view_source",
                            "url": source_url
                        }
                    ]
                },
                block_divider
            ]
        })
    )


@app.action("ingred_recipe_add_missing_to_shop_list")
def add_missing_ingredients_to_shop_list(ack, say, body, logger):
    ack()
    logger.info(body)

    missing_ingredients = body.get("actions")[0].get("value").split(", ")
    for ingred in missing_ingredients:
        add_item_to_shopping_list(ingred, True)
    say(f"Added *{len(missing_ingredients)} items* to your shopping list")


# # # # # # # # # # # # # # # # # #
# #    LISTENING TO OPTIONS     # #
# # # # # # # # # # # # # # # # # #


@app.options("ingred_multi_select")
def multi_select_ingredient_search(ack, payload):
    search_response = search_all_ingredients(payload.get("value"))
    print(f"Multi-select search results for {payload.get('value')}: {search_response.get('results')}")
    options = []

    for result in search_response.get("results"):
        options.append({
            "text": {
                "type": "plain_text",
                "text": result.get("name")
            },
            "value": result.get("name")
        })

    ack(options=options)


@app.options("ingred_nutrient_select")
def handle_some_options(ack, payload):
    search_response = search_all_ingredients(payload.get("value"))
    print(f"Select search results for {payload.get('value')}: {search_response.get('results')}")
    options = []

    for result in search_response.get("results"):
        options.append({
            "text": {
                "type": "plain_text",
                "text": result.get("name")
            },
            "value": str(result.get("id"))
        })

    ack(options=options)


# # # # # # # # # # # # # # # # # #
# #      START YOUR APP         # #
# # # # # # # # # # # # # # # # # #


SlackRequestHandler.clear_all_log_handlers()
logging.basicConfig(format="%(asctime)s %(message)s", level=logging.DEBUG)


def handler(event, context):
    slack_handler = SlackRequestHandler(app=app)
    return slack_handler.handle(event, context)


# Start your app
# if __name__ == "__main__":
    # app.start(port=int(os.environ.get("PORT", 3000)))
